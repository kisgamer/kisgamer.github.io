function setup() {
  createCanvas(1520, 720);
  background(0);
}
var currentPath = []
var drawing = []
function draw() {
  if(mouseIsPressed) {
    var pos = {
      x: mouseX,
      y: mouseY
    }
    drawing.push(pos);
  } 
  beginShape();
  stroke(255);
  strokeWeight(2);
  noFill();
  for (var i = 0; i < drawing.length; i++) {
    vertex(drawing[i].x, drawing[i].y)
  }
  endShape();
}


